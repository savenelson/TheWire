#include "app.h"

int main() {

  App app;
  app.run();

  return 0;
}
