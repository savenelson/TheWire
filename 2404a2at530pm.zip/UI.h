#ifndef UI_H
#define UI_H

#include <string>
#include <sstream>
using namespace std;

class UI
{
  public:
  static int menuPrint();
};

#endif
